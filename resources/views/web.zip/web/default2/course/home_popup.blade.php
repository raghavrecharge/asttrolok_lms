<!--<div class="modal fade" id="myModal" role="dialog">-->
<!--    <div class="modal-dialog">-->
    
      <!-- Modal content-->
<!--      <div class="modal-content">-->
<!--        <div class="modal-header">-->
<!--          <button type="button" class="close" data-dismiss="modal">&times;</button>-->
<!--          <h4 class="modal-title">Modal Header</h4>-->
<!--        </div>-->
<!--        <div class="modal-body">-->
<!--          <p>Some text in the modal.</p>-->
<!--        </div>-->
<!--        <div class="modal-footer">-->
<!--          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
<!--        </div>-->
<!--      </div>-->
      
<!--    </div>-->
<!--  </div>-->
  <div class="modal fade" id="home_popup" tabindex="-1" aria-labelledby="home_popup" aria-hidden="true">
    <div class="pop_up_size123 modal-dialog modal-lg modal-dialog-centered " >
        <div class="modal-content py-5">
            <div class="d-flex align-items-center justify-content-between px-20">
                <h3 class="section-title after-line"></h3>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i data-feather="x" width="25" height="25">X</i>
                </button>
            </div>

            <div class="mt-5 position-relative">
                

                

                <img src="{{ config('app.img_dynamic_url') }}/store/1/Home/WhatsApp Image 2025-05-15 at 4.09.56 PM.jpeg" alt="3 Days Astrology Workshop" width="100%">
                
                
            </div>
            <div class="mt-5 position-relative" >
                
 
                <center><a target="_blank" href="https://workshop.asttrolok.com/" class="btn btn-primary btn-block" style="width:52%;">Buy Now</a></center>
            </div>
        </div>
    </div>
</div>
