@php
    $showLoading = true;

    if(
        (!empty($noticeboards) and $noticeboards) or
        !empty($assignment) or
        (!empty($isForumPage) and $isForumPage) or
        (!empty($isForumAnswersPage) and $isForumAnswersPage)
    ) {
        $showLoading = false;
    }
@endphp

<div class="learning-content" id="learningPageContent">1

    @if(!empty($isForumAnswersPage) and $isForumAnswersPage)
        @include('web.default.subscription.learningPage.components.forum.forum_answers')
    @elseif(!empty($isForumPage) and $isForumPage)
        @include('web.default.subscription.learningPage.components.forum.forum')
    @elseif(!empty($noticeboards) and $noticeboards)
        @include('web.default.subscription.learningPage.components.noticeboards')
    @elseif(!empty($assignment))
        @include('web.default.subscription.learningPage.components.assignment')
    @endif
<div id="learningPageContent1">
    <div class="learning-content-loading align-items-center justify-content-center flex-column w-100 h-100 {{ $showLoading ? 'd-flex' : 'd-none' }}">
        <img src="{{ config('app.js_css_url') }}/assets/default/img/loading.gif" alt="">
        <p class="mt-10">{{ trans('update.please_wait_for_the_content_to_load') }}</p>
    </div>
     </div>
</div>
